﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Add_Order : MaterialSkin.Controls.MaterialForm
    {
        DataTable table = new DataTable();
        DBClinicTableAdapters.ORDERTableAdapter oRDER = new DBClinicTableAdapters.ORDERTableAdapter();
        public Add_Order()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Red900, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Red700, MaterialSkin.TextShade.WHITE);
            this.VisibleChanged += Add_Order_VisibleChanged;
        }

        private void Add_Order_VisibleChanged(object sender, EventArgs e)
        {
            this.oRDERTableAdapter.Fill(this.dBClinic.ORDER);
            oRDERBindingSource.DataSource = this.dBClinic.ORDER;
            oRDERDataGridView.DataSource = oRDERBindingSource;
            oRDERDataGridView.Update();
            oRDERDataGridView.Refresh();
        }
      
        private void oRDERBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.oRDERBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dBClinic);

        }

        private void Add_Order_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBClinic.ORDER' table. You can move, or remove it, as needed.
            this.oRDERTableAdapter.Fill(this.dBClinic.ORDER);

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            if (materialSingleLineTextField1.Text!="" && materialSingleLineTextField2.Text!="" && materialSingleLineTextField3.Text!="" && materialSingleLineTextField4.Text!="" && materialSingleLineTextField5.Text!="")
            {
                oRDER.Insert(Convert.ToInt32(materialSingleLineTextField1.Text), Convert.ToInt32(materialSingleLineTextField2.Text), Convert.ToInt32(materialSingleLineTextField3.Text), materialSingleLineTextField4.Text, Convert.ToInt32(materialSingleLineTextField5.Text));
                table = oRDER.GetDataBy(Convert.ToInt32(materialSingleLineTextField1.Text));
                oRDERDataGridView.DataSource = null;
                oRDERDataGridView.Rows.Clear();
                oRDERDataGridView.DataSource = table;
                oRDERDataGridView.Refresh();
            }
            else
                MessageBox.Show("Missing INFO");
        }
    }
}
