﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Add_Patient : MaterialSkin.Controls.MaterialForm
    {
        DataTable table = new DataTable();
        DBClinicTableAdapters.PATIENTTableAdapter pATIENT = new DBClinicTableAdapters.PATIENTTableAdapter();
        public Add_Patient()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Red900, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Red700, MaterialSkin.TextShade.WHITE);
            this.VisibleChanged += Add_Patient_VisibleChanged;
        }

        private void Add_Patient_VisibleChanged(object sender, EventArgs e)
        {
            this.pATIENTTableAdapter.Fill(this.dBClinic.PATIENT);
            pATIENTBindingSource.DataSource = this.dBClinic.PATIENT;
            eMPLOYEEDataGridView.DataSource = pATIENTBindingSource;
            eMPLOYEEDataGridView.Update();
            eMPLOYEEDataGridView.Refresh();
        }
      

        private void Add_Patient_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBClinic2.PATIENT' table. You can move, or remove it, as needed.
            this.pATIENTTableAdapter.Fill(this.dBClinic2.PATIENT);
            // TODO: This line of code loads data into the 'dBClinic1.PATIENT' table. You can move, or remove it, as needed.
            this.pATIENTTableAdapter.Fill(this.dBClinic1.PATIENT);
            // TODO: This line of code loads data into the 'dBClinic.EMPLOYEE' table. You can move, or remove it, as needed.
            this.eMPLOYEETableAdapter.Fill(this.dBClinic.EMPLOYEE);

        }

        private void btnadd_patient_Click(object sender, EventArgs e)
        {
            //dBClinic.EnforceConstraints = false;
            //dBClinic.PATIENT.AddPATIENTRow(17189, 20, materialSingleLineTextField1.Text + " " + materialSingleLineTextField2.Text, Convert.ToInt32(materialSingleLineTextField4.Text) , "Have Issues", System.DateTime.Today);
            //eMPLOYEE.Insert(17189, materialSingleLineTextField1.Text + " " + materialSingleLineTextField2.Text, Convert.ToInt32(materialSingleLineTextField4.Text), "Saturday","Password" );
            //dBClinic.EnforceConstraints = true;
            //eMPLOYEE.DeleteID(17189);
            //table = eMPLOYEE.GetDataBy(17189);
            //pATIENT.Insert()
            string c = null;
            if (materialRadioButton1.Checked)
                c = materialRadioButton1.Text;
            else if (materialRadioButton2.Checked)
                c = materialRadioButton2.Text;
            if (materialSingleLineTextField1.Text != "" && materialSingleLineTextField2.Text != "" && materialSingleLineTextField3.Text != "" && materialSingleLineTextField4.Text != "" && materialSingleLineTextField5.Text != "" && (materialRadioButton1.Checked || materialRadioButton2.Checked) && materialSingleLineTextField6.Text!="")
            {
                pATIENT.Insert(Convert.ToInt64(materialSingleLineTextField5.Text), materialSingleLineTextField1.Text + " " + materialSingleLineTextField2.Text, materialSingleLineTextField3.Text, Convert.ToInt32(materialSingleLineTextField4.Text),comboBox1.SelectedItem+"-"+comboBox2.SelectedItem+"-"+comboBox3.SelectedItem,c,Convert.ToInt32(materialSingleLineTextField6.Text));
                table = pATIENT.GetDataBy(Convert.ToInt64(materialSingleLineTextField5.Text));
                eMPLOYEEDataGridView.DataSource = null;
                eMPLOYEEDataGridView.Rows.Clear();
                eMPLOYEEDataGridView.DataSource = table;
                eMPLOYEEDataGridView.Refresh();
            }
            else
                MessageBox.Show("Missing INFO");

        }
    }
}
