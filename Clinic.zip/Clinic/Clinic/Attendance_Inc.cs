﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Attendance_Inc : MaterialSkin.Controls.MaterialForm
    {
        DBClinicTableAdapters.EMPLOYEETableAdapter eMPLOYEE = new DBClinicTableAdapters.EMPLOYEETableAdapter();
        public Attendance_Inc()
        {
            InitializeComponent();

        }

        private void Attendance_Inc_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBClinic.EMPLOYEE' table. You can move, or remove it, as needed.
            this.eMPLOYEETableAdapter.Fill(this.dBClinic.EMPLOYEE);

        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            if (eMPLOYEE.GetAttendance(Convert.ToInt32(comboBox1.SelectedValue)) == null || eMPLOYEE.GetAttendance(Convert.ToInt32(comboBox1.SelectedValue)) < 5)
            {

                int v;
                v = 0;
                if (eMPLOYEE.GetAttendance(Convert.ToInt32(comboBox1.SelectedValue)) != null)
                    v = Convert.ToInt32(eMPLOYEE.GetAttendance(Convert.ToInt32(comboBox1.SelectedValue)));
                v++;
                eMPLOYEE.UpdateAttendance(v, Convert.ToInt32(Convert.ToInt32(comboBox1.SelectedValue)));
            }
            else if (eMPLOYEE.GetAttendance(Convert.ToInt32(comboBox1.SelectedValue)) == 5)
            {
                eMPLOYEE.UpdateAttendance(1, Convert.ToInt32(comboBox1.SelectedValue));
            }
            attendanceTextBox.Text = eMPLOYEE.GetAttendance(Convert.ToInt32(comboBox1.SelectedValue)).ToString();
            attendanceTextBox.Refresh();
            //eMPLOYEEDataGridView.DataSource = eMPLOYEE.GetData();
            //Get Data Refresh Grid View
            //eMPLOYEEDataGridView.Refresh();
        }
    }
}
