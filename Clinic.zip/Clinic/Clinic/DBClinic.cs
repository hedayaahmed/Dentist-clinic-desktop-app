﻿namespace Clinic
{


    public partial class DBClinic
    {
    }
}

namespace Clinic.DBClinicTableAdapters
{
    partial class PATIENTTableAdapter
    {
    }

    public partial class EMPLOYEETableAdapter {
    }
}
