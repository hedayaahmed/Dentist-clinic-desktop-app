﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Employee : MaterialSkin.Controls.MaterialForm
    {
        public Employee()
        {
            InitializeComponent();
            this.VisibleChanged += Employee_VisibleChanged;
        }

        private void Employee_VisibleChanged(object sender, EventArgs e)
        {
            this.eMPLOYEETableAdapter.Fill(this.dBClinic.EMPLOYEE);
            eMPLOYEEBindingSource.DataSource = this.dBClinic.EMPLOYEE;
            eMPLOYEEDataGridView.DataSource = eMPLOYEEBindingSource;
            eMPLOYEEDataGridView.Update();
            eMPLOYEEDataGridView.Refresh();
        }

        private void eMPLOYEEBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.eMPLOYEEBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dBClinic);

        }

        private void Employee_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBClinic.EMPLOYEE' table. You can move, or remove it, as needed.
            this.eMPLOYEETableAdapter.Fill(this.dBClinic.EMPLOYEE);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.eMPLOYEETableAdapter.Fill(this.dBClinic.EMPLOYEE);
            eMPLOYEEBindingSource.DataSource = this.dBClinic.EMPLOYEE;
            eMPLOYEEDataGridView.DataSource = eMPLOYEEBindingSource;
            eMPLOYEEDataGridView.Update();
            eMPLOYEEDataGridView.Refresh();
        }
    }
}
