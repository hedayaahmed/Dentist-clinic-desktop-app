﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Generate_Report : MaterialSkin.Controls.MaterialForm
    {
        PrintDocument printDocument1 = new PrintDocument();
        PrintDialog dlg = new PrintDialog();
        public Generate_Report()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Red900, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Red700, MaterialSkin.TextShade.WHITE);
            this.VisibleChanged += Generate_Report_VisibleChanged;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
        }

        private void Generate_Report_VisibleChanged(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label1.ForeColor = Color.Red;
            label2.ForeColor = Color.Red;
            label3.ForeColor = Color.Red;
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            int ps = Convert.ToInt32(patientTableAdapter1.ScalarQuery());
            int es=Convert.ToInt32(employeeTableAdapter1.ScalarQuery());
            int os = Convert.ToInt32(orderTableAdapter1.ScalarQuery());
            int TOTAL = ps + es + os;
            int Expenses = os + es;
            int profit = TOTAL - Expenses;
            label1.Text = Expenses.ToString();
            label2.Text = profit.ToString();
            label3.Text = TOTAL.ToString();
        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
            CaptureScreen();
            printDocument1.Print();
        }

        Bitmap memoryImage;

            private void CaptureScreen()
            {
                Graphics myGraphics = this.CreateGraphics();
                Size s = this.Size;
                memoryImage = new Bitmap(s.Width, s.Height, myGraphics);
                Graphics memoryGraphics = Graphics.FromImage(memoryImage);
                memoryGraphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, s);
            }

            private void printDocument1_PrintPage(System.Object sender,
                   System.Drawing.Printing.PrintPageEventArgs e)
            {
                e.Graphics.DrawImage(memoryImage, 0, 0);
            }

        }
    }
