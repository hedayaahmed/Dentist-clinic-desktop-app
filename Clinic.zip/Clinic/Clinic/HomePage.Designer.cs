﻿namespace Clinic
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            this.btnview_patient = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnView_attend = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnadd_order = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btnview_order = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGen_Rep = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.SuspendLayout();
            // 
            // btnview_patient
            // 
            this.btnview_patient.Depth = 0;
            this.btnview_patient.Location = new System.Drawing.Point(61, 235);
            this.btnview_patient.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnview_patient.Name = "btnview_patient";
            this.btnview_patient.Primary = true;
            this.btnview_patient.Size = new System.Drawing.Size(179, 32);
            this.btnview_patient.TabIndex = 1;
            this.btnview_patient.Text = "View Patients";
            this.btnview_patient.UseVisualStyleBackColor = true;
            this.btnview_patient.Click += new System.EventHandler(this.btnview_patient_Click);
            // 
            // btnView_attend
            // 
            this.btnView_attend.Depth = 0;
            this.btnView_attend.Location = new System.Drawing.Point(61, 285);
            this.btnView_attend.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnView_attend.Name = "btnView_attend";
            this.btnView_attend.Primary = true;
            this.btnView_attend.Size = new System.Drawing.Size(179, 32);
            this.btnView_attend.TabIndex = 2;
            this.btnView_attend.Text = "Attendance";
            this.btnView_attend.UseVisualStyleBackColor = true;
            this.btnView_attend.Click += new System.EventHandler(this.btnView_attend_Click);
            // 
            // btnadd_order
            // 
            this.btnadd_order.Depth = 0;
            this.btnadd_order.Location = new System.Drawing.Point(572, 235);
            this.btnadd_order.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnadd_order.Name = "btnadd_order";
            this.btnadd_order.Primary = true;
            this.btnadd_order.Size = new System.Drawing.Size(162, 32);
            this.btnadd_order.TabIndex = 3;
            this.btnadd_order.Text = "Add Order";
            this.btnadd_order.UseVisualStyleBackColor = true;
            this.btnadd_order.Click += new System.EventHandler(this.btnadd_order_Click);
            // 
            // btnview_order
            // 
            this.btnview_order.Depth = 0;
            this.btnview_order.Location = new System.Drawing.Point(572, 284);
            this.btnview_order.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnview_order.Name = "btnview_order";
            this.btnview_order.Primary = true;
            this.btnview_order.Size = new System.Drawing.Size(162, 33);
            this.btnview_order.TabIndex = 4;
            this.btnview_order.Text = "View Order";
            this.btnview_order.UseVisualStyleBackColor = true;
            this.btnview_order.Click += new System.EventHandler(this.btnview_order_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(54, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 39);
            this.label1.TabIndex = 5;
            this.label1.Text = "Welcome ";
            // 
            // btnGen_Rep
            // 
            this.btnGen_Rep.Depth = 0;
            this.btnGen_Rep.Location = new System.Drawing.Point(323, 344);
            this.btnGen_Rep.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnGen_Rep.Name = "btnGen_Rep";
            this.btnGen_Rep.Primary = true;
            this.btnGen_Rep.Size = new System.Drawing.Size(178, 41);
            this.btnGen_Rep.TabIndex = 6;
            this.btnGen_Rep.Text = "Generate Report";
            this.btnGen_Rep.UseVisualStyleBackColor = true;
            this.btnGen_Rep.Click += new System.EventHandler(this.btnGen_Rep_Click);
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(572, 138);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(162, 30);
            this.materialRaisedButton1.TabIndex = 7;
            this.materialRaisedButton1.Text = "Employees";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 481);
            this.Controls.Add(this.materialRaisedButton1);
            this.Controls.Add(this.btnGen_Rep);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnview_order);
            this.Controls.Add(this.btnadd_order);
            this.Controls.Add(this.btnView_attend);
            this.Controls.Add(this.btnview_patient);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "HomePage";
            this.Sizable = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Homepage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MaterialSkin.Controls.MaterialRaisedButton btnview_patient;
        private MaterialSkin.Controls.MaterialRaisedButton btnView_attend;
        private MaterialSkin.Controls.MaterialRaisedButton btnadd_order;
        private MaterialSkin.Controls.MaterialRaisedButton btnview_order;
        private System.Windows.Forms.Label label1;
        private MaterialSkin.Controls.MaterialRaisedButton btnGen_Rep;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
    }
}