﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class HomePage : MaterialSkin.Controls.MaterialForm
    {
        Attendance_Inc attend = new Attendance_Inc();
        View_Patient view = new View_Patient();
        Generate_Report gen = new Generate_Report();
        Add_Order add_Order = new Add_Order();
        View_Orders view_Orders = new View_Orders();
        Employee employee = new Employee();
        public HomePage()
        {
            this.Load += HomePage_Load;
            attend.FormClosing += Attend_FormClosing1;
            view.FormClosing += View_FormClosing;
            gen.FormClosing += Gen_FormClosing;
            add_Order.FormClosing += Add_Order_FormClosing;
            view_Orders.FormClosing += View_Orders_FormClosing;
            employee.FormClosing += Employee_FormClosing;
            InitializeComponent();
        }

        private void Employee_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            employee.Hide();
        }

        private void Attend_FormClosing1(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            attend.Hide();
        }

        private void View_Orders_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            view_Orders.Hide();
        }

        private void Add_Order_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            add_Order.Hide();
        }

        private void Gen_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            gen.Hide();
        }

        private void View_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            view.Hide();
        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Red900, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Red700, MaterialSkin.TextShade.WHITE);
            label1.Text += "Doctor";
            //Doctor Lel User Login
        }

        private void btnview_patient_Click(object sender, EventArgs e)
        {
            view.Show();
        }

        private void btnView_attend_Click(object sender, EventArgs e)
        {
            attend.Show();
        }

        private void btnGen_Rep_Click(object sender, EventArgs e)
        {
            gen.Show();
        }

        private void btnadd_order_Click(object sender, EventArgs e)
        {
            add_Order.Show();
        }

        private void btnview_order_Click(object sender, EventArgs e)
        {
            view_Orders.Show();
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            employee.Show();
        }
    }
}
