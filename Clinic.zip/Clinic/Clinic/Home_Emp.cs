﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Home_Emp : MaterialSkin.Controls.MaterialForm
    {
        Add_Patient patient = new Add_Patient();
        View_Patient view = new View_Patient();
        Generate_Report gen = new Generate_Report();
        Add_Order add_Order = new Add_Order();
        View_Orders view_Orders = new View_Orders();
        Attendance_Inc inc = new Attendance_Inc();
        Supplier supplier = new Supplier();
        Schedule schedule = new Schedule();
        public Home_Emp()
        {
            view.FormClosing += View_FormClosing;
            gen.FormClosing += Gen_FormClosing;
            add_Order.FormClosing += Add_Order_FormClosing;
            view_Orders.FormClosing += View_Orders_FormClosing;
            patient.FormClosing += Patient_FormClosing;
            inc.FormClosing += Inc_FormClosing;
            supplier.FormClosing += Supplier_FormClosing;
            schedule.FormClosing += Schedule_FormClosing;
            InitializeComponent();
        }

        private void Schedule_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            schedule.Hide();
        }

        private void Supplier_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            supplier.Hide();
        }

        private void Inc_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            inc.Hide();
        }

        private void Patient_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            patient.Hide();
            //patient.
        }

        private void View_Orders_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            view_Orders.Hide();
        }

        private void Add_Order_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            add_Order.Hide();
        }

        private void Gen_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            gen.Hide();
        }

        private void View_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            view.Hide();
        }

        private void Home_Emp_Load(object sender, EventArgs e)
        {
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Red900, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Red700, MaterialSkin.TextShade.WHITE);
        }

        private void btnadd_patient_Click(object sender, EventArgs e)
        {
            patient.Show();
        }

        private void btnview_patient_Click(object sender, EventArgs e)
        {           
            view.Show();
        }

        private void btnview_sch_Click(object sender, EventArgs e)
        {
            schedule.Show();
        }

        private void btnadd_order_Click_1(object sender, EventArgs e)
        {
            add_Order.Show();
        }

        private void btnview_order_Click_1(object sender, EventArgs e)
        {
            view_Orders.Show();
        }

        private void btnGen_Rep_Click_1(object sender, EventArgs e)
        {
            gen.Show();
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            inc.Show();
        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
            supplier.Show();
        }
    }
}
