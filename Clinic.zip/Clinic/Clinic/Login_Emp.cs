﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Login_Emp : MaterialSkin.Controls.MaterialForm
    {
        Home_Emp Emp = new Home_Emp();
        DataSet data = new DataSet();
        DBClinic.EMPLOYEEDataTable table = new DBClinic.EMPLOYEEDataTable();
        DataRow row;
        string s;
        bool l = false;
        public Login_Emp()
        {
            InitializeComponent();
            Emp.FormClosed += Emp_FormClosed;
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Red900, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Red700, MaterialSkin.TextShade.WHITE);
        }


        private void Emp_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            string pass = null;
            employeeTableAdapter1.Fill(this.dbClinic1.EMPLOYEE);
            //pass = tableAdapterManager1.EemployeeTableAdapter1.GetDataBy4(Convert.ToInt32(materialSingleLineTextField1.Text)).ToString();            
            pass = employeeTableAdapter1.GETPASSWORD(Convert.ToInt32(materialSingleLineTextField1.Text));
            //employeeTableAdapter1.Fill(this.dbClinic1.EMPLOYEE);
            if (pass != null && materialSingleLineTextField2.Text==pass.ToString()) 
            {
                this.Hide();
                Emp.Show();
            }
            else
            {
                MessageBox.Show("WRONG OR MISSING INFO");
            }
        }

        private void materialSingleLineTextField2_KeyDown(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                case Keys.Enter:
                    l = true;
                    break;
            }
        }

        private void materialSingleLineTextField2_KeyUp(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                case Keys.Enter:
                    materialRaisedButton1.PerformClick();
                    l = false;
                    break;
            }
        }
    }
}
