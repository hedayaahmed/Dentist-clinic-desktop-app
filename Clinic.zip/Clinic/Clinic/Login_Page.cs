﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MaterialSkin;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Login_Page : MaterialSkin.Controls.MaterialForm
    {
        bool p = false;
        HomePage home = new HomePage();
        public Login_Page()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Red900, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Red700, MaterialSkin.TextShade.WHITE);
            home.FormClosed += Home_FormClosed;
        }

        private void Home_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {

            if (materialSingleLineTextField1.Text=="doctor" && materialSingleLineTextField2.Text=="admin")
            {
                this.Hide();
                home.Show();
            }
            else
            {
                MessageBox.Show("Wrong Credentials");
            }
        }

        private void materialSingleLineTextField2_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    p = true;
                    break;
            }
        }

        private void materialSingleLineTextField2_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    if (p==true)
                    {
                        materialRaisedButton1.PerformClick();
                        p = false;
                    }
                    break;
            }
        }
    }
}
