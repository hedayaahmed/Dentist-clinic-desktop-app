﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Schedule : MaterialSkin.Controls.MaterialForm
    {
        public Schedule()
        {
            InitializeComponent();
            this.VisibleChanged += Schedule_VisibleChanged;
        }

        private void Schedule_VisibleChanged(object sender, EventArgs e)
        {
            this.schedul2TableAdapter.Fill(this.dBClinic.Schedul2);
            schedul2BindingSource.DataSource = this.dBClinic.Schedul2;
            schedul2DataGridView.DataSource = schedul2BindingSource;
            schedul2DataGridView.Update();
            schedul2DataGridView.Refresh();
        }

        private void schedul2BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.schedul2BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dBClinic);
        }

        private void Schedule_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBClinic.Schedul2' table. You can move, or remove it, as needed.
            this.schedul2TableAdapter.Fill(this.dBClinic.Schedul2);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.schedul2TableAdapter.Fill(this.dBClinic.Schedul2);
            schedul2BindingSource.DataSource = this.dBClinic.Schedul2;
            schedul2DataGridView.DataSource = schedul2BindingSource;
            schedul2DataGridView.Update();
            schedul2DataGridView.Refresh();
        }
    }
}
