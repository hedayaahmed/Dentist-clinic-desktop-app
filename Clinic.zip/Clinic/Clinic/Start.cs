﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Start : MaterialSkin.Controls.MaterialForm
    {
        Login_Page Doc = new Login_Page();
        Login_Emp Emp = new Login_Emp();
        public Start()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Blue900, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Red700, MaterialSkin.TextShade.WHITE);
            Doc.FormClosed += Doc_FormClosed;
            Emp.FormClosed += Emp_FormClosed;
        }


        private void Emp_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void Doc_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Doc.Show();
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Emp.Show();
        }
    }
}
