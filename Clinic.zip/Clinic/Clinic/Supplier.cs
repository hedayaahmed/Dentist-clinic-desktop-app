﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class Supplier : MaterialSkin.Controls.MaterialForm
    {
        public Supplier()
        {
            InitializeComponent();
            this.VisibleChanged += Supplier_VisibleChanged;
        }

        private void Supplier_VisibleChanged(object sender, EventArgs e)
        {
            this.sUPPLIERTableAdapter.Fill(this.dBClinic.SUPPLIER);
            sUPPLIERBindingSource.DataSource = this.dBClinic.SUPPLIER;
            sUPPLIERDataGridView.DataSource = sUPPLIERBindingSource;
            sUPPLIERDataGridView.Update();
            sUPPLIERDataGridView.Refresh();
        }

        private void sUPPLIERBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sUPPLIERBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dBClinic);

        }

        private void Supplier_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBClinic.SUPPLIER' table. You can move, or remove it, as needed.
            this.sUPPLIERTableAdapter.Fill(this.dBClinic.SUPPLIER);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.sUPPLIERTableAdapter.Fill(this.dBClinic.SUPPLIER);
            sUPPLIERBindingSource.DataSource = this.dBClinic.SUPPLIER;
            sUPPLIERDataGridView.DataSource = sUPPLIERBindingSource;
            sUPPLIERDataGridView.Update();
            sUPPLIERDataGridView.Refresh();
        }
    }
}
