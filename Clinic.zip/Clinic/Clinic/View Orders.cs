﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class View_Orders : MaterialSkin.Controls.MaterialForm
    {
        public View_Orders()
        {
            InitializeComponent();
            this.VisibleChanged += View_Orders_VisibleChanged;
        }

        private void View_Orders_VisibleChanged(object sender, EventArgs e)
        {
            this.oRDERTableAdapter.Fill(this.dBClinic.ORDER);
            oRDERBindingSource.DataSource = this.dBClinic.ORDER;
            oRDERDataGridView.DataSource = oRDERBindingSource;
            oRDERDataGridView.Update();
            oRDERDataGridView.Refresh();
        }

        private void oRDERBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.oRDERBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dBClinic);

        }

        private void View_Orders_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBClinic.ORDER' table. You can move, or remove it, as needed.
            this.oRDERTableAdapter.Fill(this.dBClinic.ORDER);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.oRDERTableAdapter.Fill(this.dBClinic.ORDER);
            oRDERBindingSource.DataSource = this.dBClinic.ORDER;
            oRDERDataGridView.DataSource = oRDERBindingSource;
            oRDERDataGridView.Update();
            oRDERDataGridView.Refresh();
        }
    }
}
