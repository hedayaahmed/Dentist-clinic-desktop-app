﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic
{
    public partial class View_Patient : MaterialSkin.Controls.MaterialForm
    {
        int f = 0;
        public View_Patient()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Red900, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Red700, MaterialSkin.TextShade.WHITE);
            this.VisibleChanged += View_Patient_VisibleChanged;
        }


        private void View_Patient_VisibleChanged(object sender, EventArgs e)
        {
            //pATIENTBindingSource.DataSource = pATIENTTableAdapter.GetData();
            //pATIENTDataGridView.DataSource = null;
            //pATIENTDataGridView.Rows.Clear();
            //pATIENTBindingSource.DataSource = this.dBClinic.PATIENT;
            //pATIENTDataGridView.DataSource = pATIENTTableAdapter.GetData(); ;
            //pATIENTBindingSource.DataSource = this.dBClinic.PATIENT;
            this.pATIENTTableAdapter.Fill(this.dBClinic.PATIENT);
            pATIENTBindingSource.DataSource = this.dBClinic.PATIENT;            
            pATIENTDataGridView.DataSource = pATIENTBindingSource;
            pATIENTDataGridView.Update();
            pATIENTDataGridView.Refresh();
        }


        //private void T_Tick(object sender, EventArgs e)
        //{
        //    pATIENTBindingSource.
        //}

        private void pATIENTBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.pATIENTBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dBClinic);
        }

        private void View_Patient_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBClinic.PATIENT' table. You can move, or remove it, as needed.
            this.pATIENTTableAdapter.Fill(this.dBClinic.PATIENT);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            //pATIENTBindingSource.DataSource = this.dBClinic.PATIENT;
            //pATIENTDataGridView.DataSource = pATIENTBindingSource;
            this.pATIENTTableAdapter.Fill(this.dBClinic.PATIENT);
            pATIENTBindingSource.DataSource = this.dBClinic.PATIENT;
            pATIENTDataGridView.DataSource = pATIENTBindingSource;
            pATIENTDataGridView.Update();
            pATIENTDataGridView.Refresh();
        }

    }
}
